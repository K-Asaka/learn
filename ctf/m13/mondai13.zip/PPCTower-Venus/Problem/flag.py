problem1 = b'FLAG{math!math!math!}'
problem2 = b'FLAG{easy_pyramid_calculation!}'
problem3 = b'FLAG{Do_you_like_operators_of_python?}'
problem4 = b'FLAG{Did_you_can_read_simple_QRCode_with_python?}'
